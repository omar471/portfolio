<!DOCTYPE html>
<html lang="en">

<head>
    <title>Omar Portfolio</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <?php include 'header.php';?>
</head>

<body data-spy="scroll" data-target=".site-navbar-target" data-offset="300">
    <nav class="navbar navbar-expand-lg navbar-dark ftco_navbar ftco-navbar-light site-navbar-target" id="ftco-navbar">
        <div class="container">
            <a class="navbar-brand" href="index.php"><span>R</span>onaldo</a>
            <button class="navbar-toggler js-fh5co-nav-toggle fh5co-nav-toggle" type="button" data-toggle="collapse" data-target="#ftco-nav" aria-controls="ftco-nav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="oi oi-menu"></span> Menu
            </button>
            <div class="collapse navbar-collapse" id="ftco-nav">
                <ul class="navbar-nav nav ml-auto">
                    <li class="nav-item"><a href="index.php" class="nav-link"><span>Home</span></a></li>
                    <li class="nav-item"><a href="index.php" class="nav-link"><span>About</span></a></li>
                    <li class="nav-item"><a href="index.php" class="nav-link"><span>Resume</span></a></li>
                    <li class="nav-item"><a href="index.php" class="nav-link"><span>Services</span></a></li>
                    <li class="nav-item"><a href="index.php" class="nav-link"><span>Projects</span></a></li>
                    <li class="nav-item"><a href="index.php" class="nav-link"><span>Skills</span></a></li>
                    <li class="nav-item"><a href="index.php" class="nav-link"><span>Contact</span></a></li>
                </ul>
            </div>
        </div>
    </nav>
    <section class="ftco-about img ftco-section ftco-no-pt ftco-no-pb" id="about-section">
        <div class="container">
            <div class="row d-flex no-gutters  pt-5">

                <div class="col-md-12 col-lg-12 pl-md-12 py-5">
                 
                    <div class="row justify-content-start pb-3">
                        <div class="col-md-12 heading-section ftco-animate  ">
            
                            <h1 class="big">About</h1>
                            <h1 class="mb-2 text-center pl-4">MY Projects</h1>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section class="ftco-about img ftco-section ftco-no-pt ftco-no-pb" id="about-section">
        <div class="container">
            <div class="row d-flex no-gutters  pt-5">
                <div class="col-md-6 col-lg-6 d-flex pt-5">
                    <div class="img-about img d-flex align-items-stretch">
                        <div class="img d-flex align-self-stretch align-items-center" style="background-image:url(images/examsystem.PNG);">
                        </div>
                    </div>
                </div>
                <div class="col-md-6 col-lg-6 pl-md-5 py-5">
                    <div class="row justify-content-start pb-3">
                        <div class="col-md-12 heading-section ftco-animate ">
                            <h1 class="big">About</h1>
                            <h3 class="mb-4">Onlien Exam System</h3>
                            <p> This is Online Quiz and Exam system where student s can give their exam online.I have weorked here as a Front End web develper.I have used html, css, Boostrap and some javascript Library.Is is also fully responsive nad mobile friendly.<br> view this project live-<a href="https://omarfarukx.000webhostapp.com/">Click here</a></p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section class="ftco-about img ftco-section ftco-no-pt ftco-no-pb" id="about-section">
        <div class="container">
            <div class="row d-flex no-gutters pt-5">
                <div class="col-md-6 col-lg-6 d-flex">
                    <div class="img-about img d-flex align-items-stretch">
                        <div class="img d-flex align-self-stretch align-items-center" style="background-image:url(images/payroll.PNG);">
                        </div>
                    </div>
                </div>
                <div class="col-md-6 col-lg-6 pl-md-5 py-5">
                    <div class="row justify-content-start pb-3">
                        <div class="col-md-12 heading-section ftco-animate ">
                            <h1 class="big">About</h1>
                            <h3 class="mb-4">Human resource and payroll management</h3>
                            <p>This is Human resource and payroll management. we can use it in office,or any organization.we can calute exployee leave,salary,payroll, tax nad many others. i have used html, css,javascript,Boostrap,Jaqury and some other library. view this project live-<a href="https://www.w3schools.com">Click here</a></p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <footer class="ftco-footer ftco-section">
        <div class="container">
            <div class="row mb-5">
                <div class="col-md">
                    <div class="ftco-footer-widget mb-4">
                        <h2 class="ftco-heading-2">About</h2>
                        <p>Far far away, behind the word mountains, far from the countries Vokalia and Consonantia, there live the blind texts.</p>
                        <ul class="ftco-footer-social list-unstyled float-md-left float-lft mt-5">
                            <li class="ftco-animate"><a href="#"><span class="icon-twitter"></span></a></li>
                            <li class="ftco-animate"><a href="#"><span class="icon-facebook"></span></a></li>
                            <li class="ftco-animate"><a href="#"><span class="icon-instagram"></span></a></li>
                        </ul>
                    </div>
                </div>
                <div class="col-md">
                    <div class="ftco-footer-widget mb-4 ml-md-4">
                        <h2 class="ftco-heading-2">Links</h2>
                        <ul class="list-unstyled">
                            <li><a href="#"><span class="icon-long-arrow-right mr-2"></span>Home</a></li>
                            <li><a href="#"><span class="icon-long-arrow-right mr-2"></span>About</a></li>
                            <li><a href="#"><span class="icon-long-arrow-right mr-2"></span>Services</a></li>
                            <li><a href="#"><span class="icon-long-arrow-right mr-2"></span>Projects</a></li>
                            <li><a href="#"><span class="icon-long-arrow-right mr-2"></span>Contact</a></li>
                        </ul>
                    </div>
                </div>
                <div class="col-md">
                    <div class="ftco-footer-widget mb-4">
                        <h2 class="ftco-heading-2">Services</h2>
                        <ul class="list-unstyled">
                            <li><a href="#"><span class="icon-long-arrow-right mr-2"></span>Web Design</a></li>
                            <li><a href="#"><span class="icon-long-arrow-right mr-2"></span>Web Development</a></li>
                            <li><a href="#"><span class="icon-long-arrow-right mr-2"></span>Business Strategy</a></li>
                            <li><a href="#"><span class="icon-long-arrow-right mr-2"></span>Data Analysis</a></li>
                            <li><a href="#"><span class="icon-long-arrow-right mr-2"></span>Graphic Design</a></li>
                        </ul>
                    </div>
                </div>
                <div class="col-md">
                    <div class="ftco-footer-widget mb-4">
                        <h2 class="ftco-heading-2">Have a Questions?</h2>
                        <div class="block-23 mb-3">
                            <ul>
                                <li><span class="icon icon-map-marker"></span><span class="text">k-188-A, jomoj road, jouar sahara, Dhaka</span></li>
                                <li><a href="#"><span class="icon icon-phone"></span><span class="text">+8801624606853</span></a></li>
                                <li><a href="#"><span class="icon icon-envelope"></span><span class="text">omarf7120@gmail.com</span></a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-12 text-center">
                    <p>
                        <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
                        Copyright &copy;<script>
                            document.write(new Date().getFullYear());

                        </script> All rights reserved <i class="icon-heart color-danger" aria-hidden="true"></i> by <a href="https://colorlib.com" target="_blank">omar faruk</a>
                        <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
                    </p>
                </div>
            </div>
        </div>
    </footer>
    <!-- loader -->
    <?php include 'footer.php';?>
</body>

</html>
